<?php
	// set "true" to enable debug output
	$datadir_debug_enabled = false;
