﻿/*
 * PLUGIN DISKSPACE
 *
 * Korean language file.
 *
 * Author: Limerainne (limerainne@gmail.com)
 */

 theUILang.diskNotification	= "경고! 디스크가 가득 찼습니다. rTorrent가 정상적으로 동작하지 않을 수 있으며, 여유 공간을 확보하기 전까지는 어떤 데이터도 다운로드되지 않습니다.";

thePlugins.get("diskspace").langLoaded();
