from __future__ import absolute_import, unicode_literals

from fake_useragent.fake import UserAgent  # noqa
