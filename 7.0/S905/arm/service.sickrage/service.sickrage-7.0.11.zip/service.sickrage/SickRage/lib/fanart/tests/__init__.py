import os

LOCALDIR = os.path.dirname(__file__)
