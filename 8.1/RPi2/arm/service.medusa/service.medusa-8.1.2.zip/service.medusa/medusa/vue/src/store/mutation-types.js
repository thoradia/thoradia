export const ADD_SERIES = 'ADD_SERIES';
export const RECEIVE_SERIES = 'RECEIVE_SERIES';
