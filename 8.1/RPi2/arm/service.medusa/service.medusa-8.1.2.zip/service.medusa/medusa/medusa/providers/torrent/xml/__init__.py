"""All torrent xml providers init."""
