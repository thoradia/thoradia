﻿/*
 * PLUGIN SCREENSHOTS
 *
 * Spanish language file.
 *
 * Author: 
 */

 theUILang.exFFMPEG		= "Capturas";
 theUILang.exFrameWidth 	= "Ancho del Frame";
 theUILang.exFramesCount	= "Cantidad de Frames";
 theUILang.exStartOffset	= "Comenzar en frame offset";
 theUILang.exBetween		= "Tiempo entre frames";
 theUILang.exSave		= "Guardar";
 theUILang.exSaveAll		= "Guardar todas";
 theUILang.exScreenshot 	= "Captura";
 theUILang.exPlayInterval	= "Intervalo de Slideshow";
 theUILang.exImageFormat	= "Formato de imagen";

thePlugins.get("screenshots").langLoaded();