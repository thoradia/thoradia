﻿/*
 * PLUGIN TRAFFIC
 *
 * Dutch language file.
 *
 * Author: rascalli (rascallim@gmail.com)
 */

 theUILang.traf 		= "Internet Verkeer";
 theUILang.perDay		= "Per dag";
 theUILang.perMonth		= "Per maand";
 theUILang.perYear		= "Per jaar";
 theUILang.allTrackers		= "Alle trackers";
 theUILang.ClearButton		= "Reset";
 theUILang.ClearQuest		= "Weet u zeker dat u de data voor de geslecteerde trackers wilt resetten ?";
 theUILang.selectedTorrent	= "Geselecteerde torrent(s)";
 theUILang.ratioDay		= "Ratio/dag";
 theUILang.ratioWeek		= "Ratio/week";
 theUILang.ratioMonth		= "Ratio/maand";
