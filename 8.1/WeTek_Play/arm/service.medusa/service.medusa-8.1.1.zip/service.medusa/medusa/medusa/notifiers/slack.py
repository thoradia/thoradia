"""Slack notifier."""
# coding=utf-8

from __future__ import unicode_literals

import json
import logging
from medusa import app, common
from medusa.logger.adapters.style import BraceAdapter
import requests
import six

log = BraceAdapter(logging.getLogger(__name__))
log.logger.addHandler(logging.NullHandler())


class Notifier(object):
    """Slack notifier class."""

    SLACK_WEBHOOK_URL = 'https://hooks.slack.com/services/'

    def notify_snatch(self, ep_name, is_proper):
        """
        Send a notification to a Slack channel when an episode is snatched.

        :param ep_name: The name of the episode snatched
        :param is_proper: Boolean. If snatch is proper or not
        """
        if app.SLACK_NOTIFY_SNATCH:
            message = common.notifyStrings[(common.NOTIFY_SNATCH, common.NOTIFY_SNATCH_PROPER)[is_proper]]
            self._notify_slack('{message} : {ep_name}'.format(message=message, ep_name=ep_name))

    def notify_download(self, ep_name):
        """
        Send a notification to a slack channel when an episode is downloaded.

        :param ep_name: The name of the episode downloaded
        """
        if app.SLACK_NOTIFY_DOWNLOAD:
            message = common.notifyStrings[common.NOTIFY_DOWNLOAD]
            self._notify_slack('{message} : {ep_name}'.format(message=message, ep_name=ep_name))

    def notify_subtitle_download(self, ep_name, lang):
        """
        Send a notification to a Slack channel when subtitles for an episode are downloaded.

        :param ep_name: The name of the episode subtitles were downloaded for
        :param lang: The language of the downloaded subtitles
        """
        if app.SLACK_NOTIFY_SUBTITLEDOWNLOAD:
            message = common.notifyStrings[common.NOTIFY_SUBTITLE_DOWNLOAD]
            self._notify_slack('{message} {ep_name}: {lang}'.format(message=message, ep_name=ep_name, lang=lang))

    def notify_git_update(self, new_version='??'):
        """
        Send a notification to a Slack channel for git updates.

        :param new_version: The new version available from git
        """
        if app.USE_SLACK:
            message = common.notifyStrings[common.NOTIFY_GIT_UPDATE_TEXT]
            title = common.notifyStrings[common.NOTIFY_GIT_UPDATE]
            self._notify_slack('{title} - {message} {version}'.format(title=title, message=message, version=new_version))

    def notify_login(self, ipaddress=''):
        """
        Send a notification to a Slack channel on login.

        :param ipaddress: The ip address the login is originating from
        """
        if app.USE_SLACK:
            message = common.notifyStrings[common.NOTIFY_LOGIN_TEXT]
            title = common.notifyStrings[common.NOTIFY_LOGIN]
            self._notify_slack(title + '{title} - {message}'.format(title=title, message=message.format(ipaddress)))

    def test_notify(self, slack_webhook):
        """
        Send a test notification.

        :param slack_webhook: The slack webhook to send the message to
        :returns: the notification
        """
        return self._notify_slack('This is a test notification from Medusa', force=True, webhook=slack_webhook)

    def _send_slack(self, message=None, webhook=None):
        """Send the http request using the Slack webhook."""
        app.SLACK_WEBHOOK = webhook or app.SLACK_WEBHOOK
        slack_webhook = self.SLACK_WEBHOOK_URL + app.SLACK_WEBHOOK.replace(self.SLACK_WEBHOOK_URL, '')

        log.info('Sending slack message: {message}', {'message': message})
        log.info('Sending slack message  to url: {url}', {'url': slack_webhook})

        if isinstance(message, six.text_type):
            message = message.encode('utf-8')

        headers = {b'Content-Type': b'application/json'}
        try:
            r = requests.post(slack_webhook, data=json.dumps(dict(text=message, username='MedusaBot')), headers=headers)
            r.raise_for_status()
        except Exception:
            log.exception('Error Sending Slack message')
            return False

        return True

    def _notify_slack(self, message='', force=False, webhook=None):
        """Send the Slack notification."""
        if not app.USE_SLACK and not force:
            return False

        return self._send_slack(message, webhook)
