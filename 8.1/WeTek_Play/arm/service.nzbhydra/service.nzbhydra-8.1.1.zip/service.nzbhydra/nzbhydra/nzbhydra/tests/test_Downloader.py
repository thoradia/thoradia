#todo: mock requests
# 
# def testThatNzbGetTestWorks():
#     from nzbhydra.downloader import Nzbget
#     nzbget = Nzbget()
#     assert nzbget.test()
#     
# 
# def testThatSabnzbdTestWorks():
#     from nzbhydra.downloader import Sabnzbd
#     sab = Sabnzbd()
#     assert sab.test()

