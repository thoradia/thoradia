from .fake import UserAgent  # noqa
