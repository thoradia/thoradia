﻿/*
 * PLUGIN THROTTLE
 *
 * Serbian language file.
 *
 * Author: Zoltan Csala (zcsala021 at gmail dot com)
 */

 theUILang.throttles		= "Канали";
 theUILang.throttle		= "Канал";
 theUILang.mnuThrottle		= "Постави канал";
 theUILang.mnuUnlimited 	= "Нема канала";
 theUILang.channelName		= "Име";
 theUILang.channelDefault	= "Default channel";

thePlugins.get("throttle").langLoaded();