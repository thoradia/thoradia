﻿/*
 * PLUGIN SCREENSHOTS
 *
 * German language file.
 *
 * Author: Dario Rugani (kontakt@rugani.de)
 */

 theUILang.exFFMPEG		= "Screenshots";
 theUILang.exFrameWidth 	= "Bild breite";
 theUILang.exFramesCount	= "Bild anzahl";
 theUILang.exStartOffset	= "Startbildversatz";
 theUILang.exBetween		= "Zeit zwischen Bildern";
 theUILang.exSave		= "Speichern";
 theUILang.exSaveAll		= "Alle speichern";
 theUILang.exScreenshot 	= "Screenshot";
 theUILang.exPlayInterval	= "Diashow-Intervall";
 theUILang.exImageFormat	= "Bildformat";

thePlugins.get("screenshots").langLoaded();