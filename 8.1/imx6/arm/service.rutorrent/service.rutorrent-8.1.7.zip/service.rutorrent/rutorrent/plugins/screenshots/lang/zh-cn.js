﻿/*
 * PLUGIN SCREENSHOTS
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.exFFMPEG		= "截图";
 theUILang.exFrameWidth 	= "帧宽度";
 theUILang.exFramesCount	= "帧数量";
 theUILang.exStartOffset	= "起始帧偏移量";
 theUILang.exBetween		= "两帧之间的时间";
 theUILang.exSave		= "保存";
 theUILang.exSaveAll		= "全部保存";
 theUILang.exScreenshot 	= "截图";
 theUILang.exPlayInterval	= "幻灯片间隔";
 theUILang.exImageFormat	= "图片格式";

thePlugins.get("screenshots").langLoaded();
