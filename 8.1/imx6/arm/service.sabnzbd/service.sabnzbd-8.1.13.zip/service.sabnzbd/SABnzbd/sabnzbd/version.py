# This file will be patched by setup.py
# The __version__ should be set to the branch name
# (e.g. "develop" or "1.2.x")

# You MUST use double quotes (so " and not ')

__version__ = "2.0.0"
__baseline__ = "55c4bef5247d51fa92db1c08ce3af6ec6601fdbf"
