# coding=utf-8
"""Tests for media package."""
