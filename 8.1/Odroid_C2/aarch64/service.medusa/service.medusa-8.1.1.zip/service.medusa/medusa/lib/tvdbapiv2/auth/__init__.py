# coding=utf-8

"""
The sessions.auth package contains custom authentication handlers for Requests.
"""
