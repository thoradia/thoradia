# coding=utf-8

from .handler import Manage
from .searches import ManageSearches
