﻿/*
 * PLUGIN DATA
 *
 * Norwegian language file.
 *
 * Author: nirosa (nirosax@gmail.com)
 */

 theUILang.getData		= "Hent Fil";
 theUILang.cantAccessData	= "Webserverbrukeren har ikke tilgang til dataen til denne torrenten.";

thePlugins.get("data").langLoaded();