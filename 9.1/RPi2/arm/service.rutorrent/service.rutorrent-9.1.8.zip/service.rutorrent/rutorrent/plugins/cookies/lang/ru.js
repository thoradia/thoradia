﻿/*
 * PLUGIN COOKIES
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.cookiesDesc = "Cookies (Формат: хост|cookie1;cookie2...)";
 theUILang.cookiesName = "Cookies";

thePlugins.get("cookies").langLoaded();