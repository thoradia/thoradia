﻿/*
 * PLUGIN EDIT
 *
 * German language file.
 *
 * Author: Dario Rugani (kontakt@rugani.de) 
 */

 theUILang.EditTrackers 		= "Torrent bearbeiten";
 theUILang.EditTorrentProperties	= "Torrent Eigenschaften";
 theUILang.errorAddTorrent		= "Fehler beim Hinzufügen der Torrent-Datei";
 theUILang.errorWriteTorrent		= "Fehler beim Schreiben der Torrent-Datei";
 theUILang.errorReadTorrent		= "Fehler beim Lesen der Torrent-Datei";
 theUILang.cantFindTorrent		= "Quell Torrent-Datei für diesen Download nicht gefunden."

thePlugins.get("edit").langLoaded();