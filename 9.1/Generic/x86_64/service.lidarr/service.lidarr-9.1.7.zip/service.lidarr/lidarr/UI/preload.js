webpackJsonp([ 1 ], {
    723: function(module, exports, __webpack_require__) {
        "use strict";
        __webpack_require__(724), __webpack_require__.p = window.Lidarr.urlBase + "/";
    },
    724: function(module, exports, __webpack_require__) {
        "use strict";
        Object.defineProperty(exports, "__esModule", {
            value: !0
        });
        var _jquery2 = _interopRequireDefault(__webpack_require__(26));
        function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : {
                default: obj
            };
        }
        (0, _interopRequireDefault(__webpack_require__(764)).default)(_jquery2.default);
        var jquery = _jquery2.default;
        window.$ = _jquery2.default, window.jQuery = _jquery2.default, exports.default = jquery;
    },
    764: function(module, exports, __webpack_require__) {
        "use strict";
        Object.defineProperty(exports, "__esModule", {
            value: !0
        }), exports.default = function() {
            var originalAjax = _jquery2.default.ajax;
            _jquery2.default.ajax = function(xhr) {
                return xhr && function(xhr) {
                    return !absUrlRegex.test(xhr.url);
                }(xhr) && (function(xhr) {
                    xhr.data && "DELETE" === xhr.type && (xhr.url.contains("?") ? xhr.url += "&" : xhr.url += "?", 
                    xhr.url += _jquery2.default.param(xhr.data), delete xhr.data);
                }(xhr), function(xhr) {
                    xhr.url.startsWith("/signalr") ? xhr.url = urlBase + xhr.url : xhr.url = apiRoot + xhr.url;
                }(xhr), function(xhr) {
                    xhr.headers = xhr.headers || {}, xhr.headers["X-Api-Key"] = window.Lidarr.apiKey;
                }(xhr)), originalAjax.apply(this, arguments);
            };
        };
        var _jquery2 = function(obj) {
            return obj && obj.__esModule ? obj : {
                default: obj
            };
        }(__webpack_require__(26));
        var absUrlRegex = /^(https?:)?\/\//i, apiRoot = window.Lidarr.apiRoot, urlBase = window.Lidarr.urlBase;
    }
}, [ 723 ]);
//# sourceMappingURL=preload.js.map