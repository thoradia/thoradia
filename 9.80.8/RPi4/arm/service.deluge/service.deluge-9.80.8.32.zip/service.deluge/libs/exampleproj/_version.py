# This file is auto-generated! Do not edit!
# Use `python -m incremental.update exampleproj` to change this file.

from incremental import Version
__version__ = Version('exampleproj', 1, 2, 3)

__all__ = ["__version__"]
