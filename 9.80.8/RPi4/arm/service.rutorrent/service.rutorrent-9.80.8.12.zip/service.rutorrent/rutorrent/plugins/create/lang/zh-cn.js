﻿/*
 * PLUGIN CREATE
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.mnu_create			= "创建 Torrent...";
 theUILang.CreateNewTorrent		= "创建新的 Torrent";
 theUILang.SelectSource			= "选择来源";
 theUILang.TorrentProperties		= "Torrent 属性";
 theUILang.PieceSize			= "分块大小";
 theUILang.Other			= "其它";
 theUILang.StartSeeding			= "开始做种";
 theUILang.PrivateTorrent		= "私有 Torrent";
 theUILang.torrentCreate		= "创建...";
 theUILang.BadTorrentData		= "你必须填写要求的字段!";
 theUILang.createExternalNotFound	= "Create 插件: 插件将不会工作. 网页服务器运行用户不能访问外部程序";
 theUILang.incorrectDirectory		= "不正确的文件夹";
 theUILang.cantExecExternal		= "不能运行外部程序";
 theUILang.createConsole		= "控制台";
 theUILang.createErrors			= "错误";
 theUILang.torrentSave			= "保存";
 theUILang.torrentKill			= "停止";
 theUILang.torrentKilled		= "进程已停止.";
 theUILang.recentTrackers		= "最近的 trackers";
 theUILang.source			= "源";

thePlugins.get("create").langLoaded();
