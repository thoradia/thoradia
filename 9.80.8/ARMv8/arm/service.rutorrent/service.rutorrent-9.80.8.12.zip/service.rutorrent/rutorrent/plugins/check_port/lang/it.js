﻿/*
 * PLUGIN CHECK_PORT
 *
 * Italian language file.
 *
 * Author: Gianni
 */

 theUILang.checkWebsiteNotFound = "Check_port plugin: Plugin will not work. Invalid configuration";
 theUILang.checkPort		= "Controlla stato porta";
 theUILang.portStatus		= [
 				  "Stato della porta sconosciuto",
 				  "La porta è chiusa",
 				  "La porta è aperta"
 				  ];

thePlugins.get("check_port").langLoaded();
