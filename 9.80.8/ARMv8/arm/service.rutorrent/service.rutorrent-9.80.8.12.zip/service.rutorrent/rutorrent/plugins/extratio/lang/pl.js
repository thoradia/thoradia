﻿/*
 * PLUGIN EXTRATIO
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.ratioRulesManager	= "Menedżer ratio";
 theUILang.mnu_ratiorule	= "Reguły ratio";
 theUILang.ratAddRule		= "Dodaj";
 theUILang.ratDelRule		= "Usuń";
 theUILang.ratUpRule		= "W górę";
 theUILang.ratDownRule		= "W dół";
 theUILang.ratioIfLegend	= "Jeżeli";
 theUILang.ratLabelContain	= "Etykieta torrenta zawiera";
 theUILang.ratTrackerContain	= "Jeden z trackerów zawiera w adresie";
 theUILang.ratTrackerPublic	= "Wszystkie trackery są publiczne";
 theUILang.ratTrackerPrivate	= "Jeden z trackerów jest prywatny";
 theUILang.ratioThenLegend	= "Wtedy";
 theUILang.setRatioTo		= "Ustaw ratio na";
 theUILang.setChannelTo		= "Ustaw limit na";
 theUILang.ratioNewRule		= "Nowa reguła";

thePlugins.get("extratio").langLoaded();
