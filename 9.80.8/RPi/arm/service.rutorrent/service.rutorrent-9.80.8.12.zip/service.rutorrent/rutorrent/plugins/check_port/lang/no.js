﻿/*
 * PLUGIN CHECK_PORT
 *
 * Norwegian language file.
 *
 * Author: nirosa (nirosax@gmail.com)
 */

 theUILang.checkWebsiteNotFound = "Check_port plugin: Plugin will not work. Invalid configuration";
 theUILang.checkPort		= "Sjekk Portstatus";
 theUILang.portStatus		= [
 				  "Portstatus er ukjent",
 				  "Port er lukket",
 				  "Port er åpen"
 				  ];

thePlugins.get("check_port").langLoaded();