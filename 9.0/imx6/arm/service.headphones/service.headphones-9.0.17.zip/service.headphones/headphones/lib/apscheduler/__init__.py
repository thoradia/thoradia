version_info = (3, 0, 1)
version = '3.0.1'
release = '3.0.1'

__version__ = release  # PEP 396
