# This file will be patched by setup.py
# The __version__ should be set to the branch name
# (e.g. "develop" or "1.2.x")

# You MUST use double quotes (so " and not ')

__version__ = "2.3.1"
__baseline__ = "f1695ec8753fbdb07bd67bdce25eeb3ebe70b972"
