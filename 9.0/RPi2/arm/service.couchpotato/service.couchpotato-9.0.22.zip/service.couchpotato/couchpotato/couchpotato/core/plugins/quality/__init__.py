from .main import QualityPlugin


def autoload():
    return QualityPlugin()
