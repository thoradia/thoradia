﻿/*
 * PLUGIN DATADIR
 *
 * Swedish language file.
 *
 * Author: Magnus Holm (holmen@brasse.se) 
 */

 theUILang.DataDir		= "Spara till";
 theUILang.DataDirMove		= "Flytta filer";
 theUILang.datadirDlgCaption	= "Torrentdatakatalog";
 theUILang.datadirDirNotFound	= "DataDir insticksprogram: Felaktig katalog";
 theUILang.datadirSetDirFail	= "DataDir insticksprogram: Opreationen misslyckades";

thePlugins.get("datadir").langLoaded();
