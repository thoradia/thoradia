﻿/*
 * PLUGIN DISKSPACE
 *
 * Polish language file.
 *
 * Author:
 */

 theUILang.diskNotification = "Uwaga! Dysk jest pełny. rTorrent może nie działać poprawnie i żadne dane nie zostaną pobrane, dopóki nie usuniesz czegoś z dysku.";

thePlugins.get("diskspace").langLoaded();
