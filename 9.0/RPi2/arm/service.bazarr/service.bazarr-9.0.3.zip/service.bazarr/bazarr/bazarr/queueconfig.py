from collections import deque

global q4ws
q4ws = deque(maxlen=10)