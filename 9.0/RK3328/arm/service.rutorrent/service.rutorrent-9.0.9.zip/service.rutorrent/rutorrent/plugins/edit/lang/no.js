﻿/*
 * PLUGIN EDIT
 *
 * Norwegian language file.
 *
 * Author: nirosa (nirosax@gmail.com)
 */

 theUILang.EditTrackers 		= "Rediger Torrent...";
 theUILang.EditTorrentProperties	= "Torrentegenskaper";
 theUILang.errorAddTorrent		= "Feil oppstod med å legge til torrentfil";
 theUILang.errorWriteTorrent		= "Feil oppstod med å skrive til torrentfil";
 theUILang.errorReadTorrent		= "Feil oppstod med å lese fra torrentfil";
 theUILang.cantFindTorrent		= "Kilde-torrentfil for denne nedlastingen ble ikke funnet."

thePlugins.get("edit").langLoaded();