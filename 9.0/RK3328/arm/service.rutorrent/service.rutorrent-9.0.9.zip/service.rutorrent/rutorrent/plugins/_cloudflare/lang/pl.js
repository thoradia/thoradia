﻿/* PLUGIN _CLOUDFLARE
 *
 * Polish language file.
 *
 * Author: 
 */

 theUILang.cannotLoadCfscrape		= "_cloudflare plugin: CfScrape module can't be loaded in Python";

thePlugins.get("_cloudflare").langLoaded();
