﻿/*
 * PLUGIN ERASEDATA
 *
 * Polish language file.
 *
 * Initial author: dolohow
 * Author: mmalisz
 */

 theUILang.Rem_torrents_content_prompt		= "Czy napewno chcesz usunąć wybrany torrent(y)? UWAGA: Zostaną usunięte wszystkie pliki z katalogu torrent'a!";
 theUILang.Delete_data_with_path		= "Usuń dane (łącznie z katalogiem)";
 theUILang.Rem_torrents_with_path_prompt	= "Czy napewno chcesz usunąć wybrany torrent(y)? UWAGA: Zostaną usunięte cały katalog torrent'a!";

thePlugins.get("erasedata").langLoaded();
