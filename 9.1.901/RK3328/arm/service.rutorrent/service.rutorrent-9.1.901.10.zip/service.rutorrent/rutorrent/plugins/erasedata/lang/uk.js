﻿/*
 * PLUGIN ERASEDATA
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (oleksandr@natalenko.name)
 */

 theUILang.Rem_torrents_content_prompt		= "Справді видалити вибрані торенти? Ця дія видалить вміст торентів.";
 theUILang.Delete_data_with_path		= "Видалити каталог";
 theUILang.Rem_torrents_with_path_prompt	= "Справді видалити вибрані торенти? Ця дія видалить усі файли в каталозі торента.";

thePlugins.get("erasedata").langLoaded();
