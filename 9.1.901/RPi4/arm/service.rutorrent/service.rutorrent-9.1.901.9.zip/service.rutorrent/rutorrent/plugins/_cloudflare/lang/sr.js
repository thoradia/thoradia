﻿/* PLUGIN _CLOUDFLARE
 *
 * Serbian language file.
 *
 * Author: 
 */

 theUILang.cannotLoadCfscrape		= "_cloudflare plugin: CfScrape module can't be loaded in Python";

thePlugins.get("_cloudflare").langLoaded();
