"""All torrent html providers init."""
