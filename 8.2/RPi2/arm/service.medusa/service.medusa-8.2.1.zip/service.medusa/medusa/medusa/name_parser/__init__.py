# coding=utf-8

"""Name Parser module."""
