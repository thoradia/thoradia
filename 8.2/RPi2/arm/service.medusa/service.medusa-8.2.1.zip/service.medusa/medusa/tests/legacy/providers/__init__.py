# coding=utf-8
"""Tests for providers package."""
