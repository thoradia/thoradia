MEDUSA.addShows.popularShows = function() {
    $.initRemoteShowGrid();
    $.rootDirCheck();
};
