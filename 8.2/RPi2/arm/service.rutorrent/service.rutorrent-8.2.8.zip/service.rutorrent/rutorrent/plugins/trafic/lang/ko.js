﻿/*
 * PLUGIN TRAFFIC
 *
 * Korean language file.
 *
 * Author: Limerainne (limerainne@gmail.com)
 */

 theUILang.traf 		= "트래픽";
 theUILang.perDay		= "일별";
 theUILang.perMonth		= "월별";
 theUILang.perYear		= "년별";
 theUILang.allTrackers		= "모든 트래커";
 theUILang.ClearButton		= "지우기";
 theUILang.ClearQuest		= "정말 선택된 트래커에 대한 통계를 지울까요?";
 theUILang.selectedTorrent	= "선택된 토렌트";
 theUILang.ratioDay		= "비율/일";
 theUILang.ratioWeek		= "비율/주";
 theUILang.ratioMonth		= "비율/월";
