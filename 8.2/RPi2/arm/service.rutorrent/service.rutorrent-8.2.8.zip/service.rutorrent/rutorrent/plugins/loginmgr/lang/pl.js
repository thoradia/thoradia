﻿/*
 * PLUGIN LoginMGR
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.accLogin		= "Login";
 theUILang.accPassword		= "Hasło";
 theUILang.accAccounts		= "Konta";
 theUILang.accAuto		= "Autologowanie";
 theUILang.acAutoNone		= "Wcale";
 theUILang.acAutoDay		= "Co dzień";
 theUILang.acAutoWeek		= "Co tydzień";
 theUILang.acAutoMonth		= "Co miesiąc";

thePlugins.get("loginmgr").langLoaded();
