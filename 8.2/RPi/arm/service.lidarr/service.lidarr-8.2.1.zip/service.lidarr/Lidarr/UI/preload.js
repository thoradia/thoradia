webpackJsonp([1],{

/***/ 713:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


__webpack_require__(714);

__webpack_require__.p = window.Lidarr.urlBase + '/'; /* eslint no-undef: 0 */

/***/ }),

/***/ 714:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _jquery = __webpack_require__(26);

var _jquery2 = _interopRequireDefault(_jquery);

var _jquery3 = __webpack_require__(754);

var _jquery4 = _interopRequireDefault(_jquery3);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

(0, _jquery4.default)(_jquery2.default);

var jquery = _jquery2.default;
window.$ = _jquery2.default;
window.jQuery = _jquery2.default;

exports.default = jquery;

/***/ }),

/***/ 754:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function () {
  var originalAjax = _jquery2.default.ajax;
  _jquery2.default.ajax = function (xhr) {
    if (xhr && isRelative(xhr)) {
      moveBodyToQuery(xhr);
      addRootUrl(xhr);
      addApiKey(xhr);
    }
    return originalAjax.apply(this, arguments);
  };
};

var _jquery = __webpack_require__(26);

var _jquery2 = _interopRequireDefault(_jquery);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var absUrlRegex = /^(https?:)?\/\//i;
var apiRoot = window.Lidarr.apiRoot;
var urlBase = window.Lidarr.urlBase;

function isRelative(xhr) {
  return !absUrlRegex.test(xhr.url);
}

function moveBodyToQuery(xhr) {
  if (xhr.data && xhr.type === 'DELETE') {
    if (xhr.url.contains('?')) {
      xhr.url += '&';
    } else {
      xhr.url += '?';
    }
    xhr.url += _jquery2.default.param(xhr.data);
    delete xhr.data;
  }
}

function addRootUrl(xhr) {
  var url = xhr.url;
  if (url.startsWith('/signalr')) {
    xhr.url = urlBase + xhr.url;
  } else {
    xhr.url = apiRoot + xhr.url;
  }
}

function addApiKey(xhr) {
  xhr.headers = xhr.headers || {};
  xhr.headers['X-Api-Key'] = window.Lidarr.apiKey;
}

/***/ })

},[713]);
//# sourceMappingURL=preload.js.map