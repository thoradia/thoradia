MEDUSA.manage.massEdit = function() {
    $('#location').fileBrowser({
        title: 'Select Show Location'
    });
};
