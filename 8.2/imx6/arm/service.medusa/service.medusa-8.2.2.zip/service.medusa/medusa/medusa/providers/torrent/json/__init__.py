"""All torrent json providers init."""
