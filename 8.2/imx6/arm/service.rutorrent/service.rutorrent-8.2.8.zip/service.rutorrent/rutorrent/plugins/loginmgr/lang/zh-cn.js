﻿/*
 * PLUGIN LoginMGR
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.accLogin		= "登录";
 theUILang.accPassword		= "密码";
 theUILang.accAccounts		= "帐号";
 theUILang.accAuto		= "自动登录";
 theUILang.acAutoNone		= "否";
 theUILang.acAutoDay		= "每天";
 theUILang.acAutoWeek		= "每周";
 theUILang.acAutoMonth		= "每月";

thePlugins.get("loginmgr").langLoaded();
