﻿/*
 * PLUGIN LoginMGR
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.accLogin		= "Логин";
 theUILang.accPassword		= "Пароль";
 theUILang.accAccounts		= "Аккаунты";
 theUILang.accAuto		= "Автологин";
 theUILang.acAutoNone		= "Нет";
 theUILang.acAutoDay		= "Каждый день";
 theUILang.acAutoWeek		= "Каждую неделю";
 theUILang.acAutoMonth		= "Каждый месяц";

thePlugins.get("loginmgr").langLoaded();