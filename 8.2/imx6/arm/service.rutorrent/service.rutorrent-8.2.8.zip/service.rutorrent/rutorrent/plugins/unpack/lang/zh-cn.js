﻿/*
 * PLUGIN UNPACK
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.unpack		= "解压缩";
 theUILang.unpackPath		= "解压到 (这里留空为 Torrents 目录)";
 theUILang.unzipNotFound	= "Unpack 插件: rTorrent 执行用户不能访问 'unzip' 程序.";
 theUILang.unrarNotFound	= "Unpack 插件: rTorrent 执行用户不能访问 'unrar' 程序.";
 theUILang.unpackEnabled	= "启用自动解压缩如果 torrent 的标签符合过滤器";
 theUILang.unpackTorrents	= "当解压缩 Torrent 数据时添加路径:";
 theUILang.unpackAddLabel	= "Torrent 的标签";
 theUILang.unpackAddName	= "Torrent 的名称";

thePlugins.get("unpack").langLoaded();
