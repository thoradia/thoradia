#!/usr/bin/env python
"""
    Run FlexGet without bootstrap and virtualenv.

    You need to have all dependencies installed in site-packages when using this.
"""

import flexget

if __name__ == '__main__':
    flexget.main()
