# coding=utf-8

"""Custom LoggingAdapters for Python logging."""
