﻿/*
 * PLUGIN SCREENSHOTS
 *
 * Swedish language file.
 *
 * Author: Magnus Holm (holmen@brasse.se) 
 */

 theUILang.exFFMPEG		= "Skärmdumpar";
 theUILang.exFrameWidth 	= "Bildrutebredd";
 theUILang.exFramesCount	= "Antal bildrutor";
 theUILang.exStartOffset	= "Start förskjutning bildrutor";
 theUILang.exBetween		= "Tid mellan bildrutor";
 theUILang.exSave		= "Spara";
 theUILang.exSaveAll		= "Spara alla";
 theUILang.exScreenshot 	= "Skärmdump";
 theUILang.exPlayInterval	= "Bildspelsintervall";
 theUILang.exImageFormat	= "Bildformat";

thePlugins.get("screenshots").langLoaded();
