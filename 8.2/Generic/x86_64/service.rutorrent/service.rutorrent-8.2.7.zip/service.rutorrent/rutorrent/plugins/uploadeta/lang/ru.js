﻿/*
 * PLUGIN UploadETA
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.uploadeta		= "ETA отдачи";
 theUILang.uploadtarget		= "Порог для отдачи";
 theUILang.ULtarget		= "Намечено отдать";
 theUILang.ULremaining		= "Осталось отдать";
 theUILang.ULETA		= "Ост. время отдачи";
 theUILang.ULdescription	= "Показывается только объём данных, оставшихся до достижения установленного порога и приблизительное время, которое для этого потребуется. Торрент не будет автоматически удалён после этого. См. параметр 'ratio.min.set' в файле конфигурации rTorrent для настройки автоматического удаления торрента по достижении установленного порога.";

thePlugins.get("uploadeta").langLoaded();