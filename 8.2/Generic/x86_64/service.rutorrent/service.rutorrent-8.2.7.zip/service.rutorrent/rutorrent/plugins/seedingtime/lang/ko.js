﻿/*
 * PLUGIN SeedingTime
 *
 * Korean language file.
 *
 * Author: Limerainne (limerainne@gmail.com)
 */

 theUILang.seedingTime		= "완료 시간";
 theUILang.addTime		= "추가 시간";

thePlugins.get("seedingtime").langLoaded();
