MEDUSA.home.postProcess = function() {
    $('#episodeDir').fileBrowser({
        title: 'Select Unprocessed Episode Folder',
        key: 'postprocessPath'
    });
};
