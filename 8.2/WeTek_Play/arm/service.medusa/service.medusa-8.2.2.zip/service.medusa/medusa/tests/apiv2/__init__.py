# coding=utf-8
"""Api v2 tests."""
import os
import sys

sys.path.insert(1, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../lib')))
sys.path.insert(1, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../ext')))
sys.path.insert(1, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))
