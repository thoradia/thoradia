"""All nzb providers init."""
