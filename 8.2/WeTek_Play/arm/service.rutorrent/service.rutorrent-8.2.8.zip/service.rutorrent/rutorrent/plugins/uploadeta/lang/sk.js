﻿/*
 * PLUGIN UploadETA
 *
 * Slovak language file.
 *
 * Author: 
 */

 theUILang.uploadeta		= "Upload ETA";
 theUILang.uploadtarget		= "Upload Target";
 theUILang.ULtarget		= "UL Target";
 theUILang.ULremaining		= "UL Remaining";
 theUILang.ULETA		= "UL ETA";
 theUILang.ULdescription	= "This plugin only will show the amount of data and time that is left to an upload ratio target. It will not automatically remove a torrent for you. Look at 'ratio.min.set' in your rTorrent configuration file to remove a torrent when a upload target has been reached.";

thePlugins.get("uploadeta").langLoaded();