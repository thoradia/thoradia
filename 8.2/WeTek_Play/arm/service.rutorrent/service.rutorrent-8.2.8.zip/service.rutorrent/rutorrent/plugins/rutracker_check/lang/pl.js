﻿/*
 * PLUGIN RUTRACKER_CHECK
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.checkTorrent 	= "Sprawdź aktualizacje";
 theUILang.chkHdr		= "Sprawdź aktualizacje torrenta";
 theUILang.checkedAt		= "Ostatnio sprawdzane";
 theUILang.checkedResult	= "Wynik";
 theUILang.chkResults		= [
 				  "W trakcie",
 				  "Zaktualizowano",
 				  "Bieżące",
 				  "Prawdopodobnie usunięte",
 				  "Błąd podczas próby dostępu do trackera",
 				  "Błąd interakcji z rTorrentem",
 				  "Nie potrzeba"
 				  ];

thePlugins.get("rutracker_check").langLoaded();