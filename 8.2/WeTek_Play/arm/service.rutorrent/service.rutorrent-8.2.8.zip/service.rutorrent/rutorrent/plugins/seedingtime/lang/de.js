﻿/*
 * PLUGIN SeedingTime
 *
 * German language file.
 *
 * Author: Dario Rugani (kontakt@rugani.de)
 */

 theUILang.seedingTime		= "Fertig";
 theUILang.addTime		= "Hinzugefügt";

thePlugins.get("seedingtime").langLoaded();