﻿/*
 * PLUGIN LoginMGR
 *
 * Spanish language file.
 *
 * Author: 
 */

 theUILang.accLogin		= "Login";
 theUILang.accPassword		= "Password";
 theUILang.accAccounts		= "Cuentas";
 theUILang.accAuto		= "Autologin";
 theUILang.acAutoNone		= "None";
 theUILang.acAutoDay		= "Every day";
 theUILang.acAutoWeek		= "Every week";
 theUILang.acAutoMonth		= "Every month";

thePlugins.get("loginmgr").langLoaded();