<?php

rTorrentSettings::get()->unregisterEventHook("_cloudflare", "URLFetched");
