# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from deluge.ui.console.cmdline.command import BaseCommand

__all__ = ['BaseCommand']
